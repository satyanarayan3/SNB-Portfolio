const rightSection = document.querySelector(".rightSection");
rightSection.addEventListener("mousemove", (e) => {
    const rect = rightSection.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;

    rightSection.querySelector("img").style.transform = `rotateY(${x / 20}deg) rotateX(${-y / 20}deg)`;
});
